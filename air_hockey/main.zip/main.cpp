/*
File Name: main.cpp
last update: 4/18
updated by: Bennett
--------------------
Read "ReadMe.txt" for info about making updates to the project - https://drive.google.com/drive/folders/11mGb5-KcbxiLJJ7Rtg52zBmQwLx8W3Lg?usp=sharing
UPDATES
--------------------
4/17
- started project
- added basic window
- added basic testing shape(circle)
--------------------
4/18
- moved #includes to Puck.h
- added include Puck.h
--------------------
4/19
- making update stuff better

*/

#include "Puck.h"



int main(void) {
	float xRef = 0, yRef = 0;
	sf::Mouse mouse;
	sf::RenderWindow window(sf::VideoMode(1000, 500), "SFML works!");
	sf::Clock c;

	sf::CircleShape shape(100.f);
	shape.setFillColor(sf::Color::Green);

	Puck shape2(30.f, sf::Vector2f(200, 200), 2.0f, 2.0f);
	cout << "Radius: " << shape2.getRadius() << endl;

	sf::RectangleShape rect(sf::Vector2f(500, 10));
	rect.setPosition(sf::Vector2f(200, 50));

	sf::CircleShape cir(30.f);
	cir.setPosition(sf::Vector2f(350, 400));

	


	window.setFramerateLimit(60);

	// start loop
	while (window.isOpen()) 
	{
		sf::Event event;
		while (window.pollEvent(event)) 
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		// this is just to test cases of collision
		cir.setPosition(sf::Vector2f(mouse.getPosition(window).x - cir.getRadius(), mouse.getPosition(window).y - cir.getRadius()));
		
		shape2.collision(&cir);
		shape2.collision(&rect);
		shape2.slide();
		
		window.clear();

		window.draw(shape2);
		window.draw(cir);
		window.draw(rect);

		window.display();
	}


	return 0;
}