/*
File Name: Puck.cpp
last update: 4/18
updated by: Bennett
--------------------
UPDATES
--------------------
4/18
- started file
- added 3 construtors
- added slide() & collision()
--------------------
4/19
- started messing around with collision, making it more universal
*/

#include "Puck.h"

Puck::Puck() : sf::CircleShape(20.f) {
	x_Velocity = 0.f;
	y_Velocity = 0.f;
}

Puck::Puck(float size, sf::Vector2f pos) : sf::CircleShape(size) {
	this->setPosition(pos);
	x_Velocity = 0.f;
	y_Velocity = 0.f;
}

Puck::Puck(float size, sf::Vector2f pos, float x_vel, float y_vel) : sf::CircleShape(size) {
	this->setPosition(pos);
	x_Velocity = x_vel;
	y_Velocity = y_vel;
}


void Puck::slide() {
	this->move(sf::Vector2f(x_Velocity, y_Velocity));
	x_Velocity = x_Velocity * 0.995;
	y_Velocity = y_Velocity * 0.995;

	// TODO: make random movments when speed is very slow, act like real life air hockey
	
}



void Puck::collision(sf::Shape* possibleCollision) {
	if (this->getGlobalBounds().intersects(possibleCollision->getGlobalBounds())) {
		if (dynamic_cast<sf::CircleShape*>(possibleCollision) != nullptr) {
			cout << "Circle ";
		}
		else if (dynamic_cast<sf::RectangleShape*>(possibleCollision) != nullptr) {
			cout << "Rectangle ";
		}
		cout << "collision" << endl;
		this->y_Velocity = this->y_Velocity * -1.3;
	}

}

float Puck::getX_Vel() {
	return x_Velocity;
}