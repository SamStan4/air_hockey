/*
File Name: Puck.h
last update: 4/18
updated by: Bennett
--------------------
UPDATES
--------------------
4/18
- started file
- started Puck class
- added 3 construtors
- added slide() & collision()

--------------------
4/19
- changed collision to accept any shape

*/

#pragma once
// these includes can be moved to other header files, this is just temporary
#include <iostream>
#include "SFML-2.5.1-x64/include/SFML/Graphics.hpp"
#include "SFML-2.5.1-x64/include/SFML/Window.hpp"
#include "SFML-2.5.1-x64/include/SFML/System.hpp"

using std::cout;
using std::endl;


class Puck : public sf::CircleShape {
public:
	Puck();
	Puck(float size, sf::Vector2f pos);
	Puck(float size, sf::Vector2f pos, float x_vel, float y_vel);

	// slide() applies the current velocity the the current position to move the puck
	void slide(); 

	// in main, use NAME.collision(OTHERNAME.getGlobalBounds());
	void collision(sf::Shape* possibleCollision);

	float getX_Vel();

private:
	float x_Velocity;
	float y_Velocity;
};